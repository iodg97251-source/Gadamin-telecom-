# GADAMIN TELECOM — prototype Android

Cette première version est une application Expo/React Native de démonstration.

## Fonctionnalités disponibles dans cette démo
- Catalogue avec téléphones d'exemple et prix FCFA
- Recherche
- Panier et quantités
- Formulaire de commande
- Choix livraison à domicile / retrait
- Choix Orange Money / Moov Money / paiement à la livraison
- Historique local des commandes
- Ajout local de produits dans l'espace admin de démonstration

## Limites importantes
- Les produits et commandes sont conservés uniquement dans la mémoire de l'application : ils ne sont pas partagés entre téléphones et peuvent disparaître à la fermeture.
- Les paiements Orange Money et Moov Money ne sont PAS connectés. La sélection d'un moyen de paiement mobile ne déclenche aucun transfert d'argent.
- L'écran Admin est une démonstration locale, sans authentification sécurisée. Ne pas publier en production avant d'ajouter une vraie authentification administrateur et des règles d'accès serveur.
- Les prix et produits affichés sont des exemples. Remplacez-les par les informations réelles de la boutique.
- La livraison et le retrait doivent être configurés avec les coordonnées réelles de la boutique.

## Lancer le projet
Installer Node.js puis exécuter :
```bash
npm install
npx expo start
```
Pour tester sur Android, installer Expo Go sur le téléphone et scanner le QR code.

## Générer un APK Android
1. Créer un compte Expo : https://expo.dev/
2. Installer EAS CLI : `npm install -g eas-cli`
3. Se connecter : `eas login`
4. Configurer : `eas build:configure`
5. Lancer la compilation : `eas build --platform android --profile preview`

Le fichier `eas.json` configure le profil preview en APK.

## Avant une vraie mise en production
Connecter Supabase, configurer l'authentification admin, les règles RLS, le stockage des images et un prestataire de paiement officiellement compatible avec Orange Money et Moov Money au Burkina Faso. Les paiements doivent être confirmés par le serveur du prestataire, jamais par une simple action dans l'application.
