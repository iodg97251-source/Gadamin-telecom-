import React, { useMemo, useState } from "react";
import {
  Alert, SafeAreaView, ScrollView, StatusBar, StyleSheet, Text,
  TextInput, TouchableOpacity, View
} from "react-native";

type Product = { id: string; name: string; brand: string; price: number; storage: string; condition: string; stock: number; description: string };
type CartLine = { product: Product; quantity: number };
type Order = { id: string; items: CartLine[]; total: number; customer: string; phone: string; address: string; delivery: string; payment: string; status: string };

const initialProducts: Product[] = [
  { id: "p1", name: "iPhone 12", brand: "Apple", price: 145000, storage: "128 Go", condition: "Occasion", stock: 3, description: "Smartphone Apple, très bon état." },
  { id: "p2", name: "Samsung Galaxy A15", brand: "Samsung", price: 85000, storage: "128 Go", condition: "Neuf", stock: 5, description: "Écran lumineux et grande autonomie." },
  { id: "p3", name: "Redmi Note 13", brand: "Xiaomi", price: 105000, storage: "256 Go", condition: "Neuf", stock: 4, description: "Écran AMOLED et appareil photo haute résolution." },
  { id: "p4", name: "Tecno Spark 20", brand: "Tecno", price: 70000, storage: "128 Go", condition: "Neuf", stock: 6, description: "Téléphone pratique pour tous les jours." },
  { id: "p5", name: "Infinix Hot 40", brand: "Infinix", price: 78000, storage: "128 Go", condition: "Neuf", stock: 2, description: "Grand écran et batterie longue durée." }
];

const money = (n: number) => `${n.toLocaleString("fr-FR")} FCFA`;

export default function App() {
  const [tab, setTab] = useState("Boutique");
  const [products, setProducts] = useState<Product[]>(initialProducts);
  const [cart, setCart] = useState<CartLine[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [search, setSearch] = useState("");
  const [customer, setCustomer] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [delivery, setDelivery] = useState("Livraison à domicile");
  const [payment, setPayment] = useState("Orange Money");
  const [newName, setNewName] = useState("");
  const [newPrice, setNewPrice] = useState("");
  const [newBrand, setNewBrand] = useState("Autre");
  const [newStock, setNewStock] = useState("1");

  const filtered = useMemo(() => products.filter(p =>
    `${p.name} ${p.brand}`.toLowerCase().includes(search.toLowerCase())
  ), [products, search]);

  const total = cart.reduce((sum, line) => sum + line.product.price * line.quantity, 0);

  function addToCart(product: Product) {
    if (product.stock < 1) return Alert.alert("Indisponible", "Ce produit est en rupture de stock.");
    setCart(old => {
      const found = old.find(x => x.product.id === product.id);
      if (found) return old.map(x => x.product.id === product.id ? { ...x, quantity: Math.min(x.quantity + 1, product.stock) } : x);
      return [...old, { product, quantity: 1 }];
    });
    Alert.alert("Ajouté", `${product.name} a été ajouté au panier.`);
  }

  function changeQty(id: string, delta: number) {
    setCart(old => old.map(x => x.product.id === id ? { ...x, quantity: x.quantity + delta } : x).filter(x => x.quantity > 0));
  }

  function placeOrder() {
    if (!cart.length) return Alert.alert("Panier vide", "Ajoutez d'abord un téléphone.");
    if (!customer.trim() || !phone.trim()) return Alert.alert("Informations manquantes", "Entrez votre nom et votre numéro de téléphone.");
    if (delivery === "Livraison à domicile" && !address.trim()) return Alert.alert("Adresse manquante", "Entrez votre quartier ou votre adresse.");
    const id = `GT-${Date.now().toString().slice(-7)}`;
    const order: Order = { id, items: cart, total, customer, phone, address, delivery, payment, status: payment === "Paiement à la livraison" ? "À confirmer par la boutique" : "En attente de vérification du paiement" };
    setOrders(old => [order, ...old]);
    setProducts(old => old.map(p => {
      const line = cart.find(x => x.product.id === p.id);
      return line ? { ...p, stock: Math.max(0, p.stock - line.quantity) } : p;
    }));
    setCart([]);
    setTab("Commandes");
    Alert.alert("Commande enregistrée", `Référence : ${id}\nLa boutique vous contactera pour confirmer la commande.\nAucun paiement mobile n'a été effectué dans cette version de démonstration.`);
  }

  function addProduct() {
    const price = Number(newPrice);
    const stock = Number(newStock);
    if (!newName.trim() || !Number.isFinite(price) || price <= 0 || !Number.isFinite(stock) || stock < 0) {
      return Alert.alert("Vérifiez les champs", "Entrez un nom, un prix et un stock valides.");
    }
    setProducts(old => [{ id: `p${Date.now()}`, name: newName.trim(), brand: newBrand, price, storage: "À préciser", condition: "À préciser", stock, description: "Produit ajouté en mode démonstration." }, ...old]);
    setNewName(""); setNewPrice(""); setNewStock("1");
    Alert.alert("Produit ajouté", "Le produit est visible dans la boutique sur cet appareil.");
  }

  const Button = ({ label, onPress, secondary = false }: { label: string; onPress: () => void; secondary?: boolean }) => (
    <TouchableOpacity onPress={onPress} style={[styles.button, secondary && styles.secondaryButton]}>
      <Text style={[styles.buttonText, secondary && styles.secondaryButtonText]}>{label}</Text>
    </TouchableOpacity>
  );

  const Choice = ({ label, value, setValue }: { label: string; value: string; setValue: (v: string) => void }) => (
    <TouchableOpacity onPress={() => setValue(label)} style={[styles.choice, value === label && styles.choiceActive]}>
      <Text style={[styles.choiceText, value === label && styles.choiceTextActive]}>{label}</Text>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor="#171717" />
      <View style={styles.header}>
        <View>
          <Text style={styles.brand}>GADAMIN <Text style={styles.orange}>TELECOM</Text></Text>
          <Text style={styles.tagline}>Votre boutique de téléphones</Text>
        </View>
        <Text style={styles.phone}>77 18 71 71</Text>
      </View>

      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        {tab === "Boutique" && <>
          <Text style={styles.heroTitle}>Bienvenue chez vous.</Text>
          <Text style={styles.muted}>Découvrez nos téléphones et accessoires.</Text>
          <TextInput value={search} onChangeText={setSearch} placeholder="Rechercher un téléphone..." style={styles.input} />
          <Text style={styles.sectionTitle}>Nos téléphones</Text>
          {filtered.map(p => <View key={p.id} style={styles.product}>
            <View style={styles.productIcon}><Text style={{fontSize: 30}}>📱</Text></View>
            <View style={{flex: 1}}>
              <Text style={styles.productName}>{p.name}</Text>
              <Text style={styles.muted}>{p.brand} • {p.storage} • {p.condition}</Text>
              <Text style={styles.price}>{money(p.price)}</Text>
              <Text style={styles.stock}>Stock : {p.stock}</Text>
              <Text style={styles.description}>{p.description}</Text>
              <Button label="Ajouter au panier" onPress={() => addToCart(p)} />
            </View>
          </View>)}
          {!filtered.length && <Text style={styles.muted}>Aucun produit trouvé.</Text>}
        </>}

        {tab === "Panier" && <>
          <Text style={styles.title}>Mon panier</Text>
          {!cart.length ? <Text style={styles.muted}>Votre panier est vide.</Text> : cart.map(line => <View key={line.product.id} style={styles.cartLine}>
            <View style={{flex: 1}}>
              <Text style={styles.productName}>{line.product.name}</Text>
              <Text style={styles.price}>{money(line.product.price * line.quantity)}</Text>
            </View>
            <TouchableOpacity style={styles.qty} onPress={() => changeQty(line.product.id, -1)}><Text>−</Text></TouchableOpacity>
            <Text style={styles.qtyText}>{line.quantity}</Text>
            <TouchableOpacity style={styles.qty} onPress={() => changeQty(line.product.id, 1)}><Text>+</Text></TouchableOpacity>
          </View>)}
          <Text style={styles.total}>Total : {money(total)}</Text>
          <Text style={styles.sectionTitle}>Vos informations</Text>
          <TextInput value={customer} onChangeText={setCustomer} placeholder="Nom complet" style={styles.input} />
          <TextInput value={phone} onChangeText={setPhone} placeholder="Numéro de téléphone" keyboardType="phone-pad" style={styles.input} />
          <Text style={styles.sectionTitle}>Réception</Text>
          <Choice label="Livraison à domicile" value={delivery} setValue={setDelivery} />
          <Choice label="Retrait en boutique" value={delivery} setValue={setDelivery} />
          {delivery === "Livraison à domicile" && <TextInput value={address} onChangeText={setAddress} placeholder="Quartier et adresse de livraison" style={styles.input} />}
          <Text style={styles.sectionTitle}>Mode de paiement</Text>
          <Choice label="Orange Money" value={payment} setValue={setPayment} />
          <Choice label="Moov Money" value={payment} setValue={setPayment} />
          <Choice label="Paiement à la livraison" value={payment} setValue={setPayment} />
          <Text style={styles.notice}>Version démo : les paiements Orange Money et Moov Money ne sont pas encore connectés. La commande sera enregistrée en attente de vérification. Ne communiquez jamais votre code PIN.</Text>
          <Button label="Confirmer ma commande" onPress={placeOrder} />
        </>}

        {tab === "Commandes" && <>
          <Text style={styles.title}>Mes commandes</Text>
          {!orders.length && <Text style={styles.muted}>Vos commandes apparaîtront ici.</Text>}
          {orders.map(o => <View key={o.id} style={styles.order}>
            <Text style={styles.productName}>Commande {o.id}</Text>
            <Text style={styles.muted}>{o.items.map(i => `${i.quantity} × ${i.product.name}`).join(", ")}</Text>
            <Text style={styles.price}>{money(o.total)}</Text>
            <Text style={styles.muted}>{o.delivery} • {o.payment}</Text>
            <Text style={styles.status}>{o.status}</Text>
          </View>)}
        </>}

        {tab === "Admin" && <>
          <Text style={styles.title}>Administration démo</Text>
          <Text style={styles.notice}>Espace de démonstration local uniquement. Il n'est pas encore protégé par une authentification serveur. Ne l'utilisez pas en production avant de connecter Supabase et une vraie authentification administrateur.</Text>
          <Text style={styles.sectionTitle}>Ajouter un téléphone</Text>
          <TextInput value={newName} onChangeText={setNewName} placeholder="Nom du téléphone" style={styles.input} />
          <TextInput value={newPrice} onChangeText={setNewPrice} placeholder="Prix en FCFA" keyboardType="numeric" style={styles.input} />
          <TextInput value={newBrand} onChangeText={setNewBrand} placeholder="Marque" style={styles.input} />
          <TextInput value={newStock} onChangeText={setNewStock} placeholder="Quantité en stock" keyboardType="numeric" style={styles.input} />
          <Button label="Publier le produit (démo)" onPress={addProduct} />
          <Text style={styles.sectionTitle}>Commandes reçues : {orders.length}</Text>
          {orders.map(o => <View key={o.id} style={styles.order}><Text style={styles.productName}>{o.id} — {o.customer}</Text><Text style={styles.muted}>{o.phone} • {money(o.total)}</Text><Text style={styles.status}>{o.status}</Text></View>)}
          <Text style={styles.sectionTitle}>Produits : {products.length}</Text>
          {products.map(p => <Text key={p.id} style={styles.listItem}>{p.name} — {money(p.price)} — stock {p.stock}</Text>)}
        </>}

        {tab === "Profil" && <>
          <Text style={styles.title}>GADAMIN TELECOM</Text>
          <Text style={styles.muted}>Boutique de téléphones au Burkina Faso.</Text>
          <View style={styles.infoCard}><Text style={styles.productName}>Contact</Text><Text style={styles.muted}>Téléphone / WhatsApp : +226 77 18 71 71</Text></View>
          <Button label="Voir la boutique" onPress={() => setTab("Boutique")} />
          <Text style={styles.notice}>Cette version est une démonstration : les données sont conservées uniquement pendant l'utilisation de l'application et ne sont pas encore synchronisées entre appareils.</Text>
        </>}
      </ScrollView>

      <View style={styles.nav}>
        {["Boutique", "Panier", "Commandes", "Admin", "Profil"].map(t => (
          <TouchableOpacity key={t} onPress={() => setTab(t)} style={styles.navItem}>
            <Text style={[styles.navText, tab === t && styles.navActive]}>{t === "Boutique" ? "⌂" : t === "Panier" ? "▣" : t === "Commandes" ? "▤" : t === "Admin" ? "⚙" : "●"}</Text>
            <Text style={[styles.navLabel, tab === t && styles.navActive]}>{t}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#F5F5F5" },
  header: { backgroundColor: "#171717", paddingHorizontal: 18, paddingVertical: 16, flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  brand: { color: "#FFFFFF", fontWeight: "900", fontSize: 20, letterSpacing: 0.5 },
  orange: { color: "#FF7A00" },
  tagline: { color: "#D1D1D1", fontSize: 11, marginTop: 3 },
  phone: { color: "#FFFFFF", fontSize: 12, fontWeight: "700" },
  content: { padding: 16, paddingBottom: 30 },
  heroTitle: { fontSize: 27, fontWeight: "900", color: "#171717", marginTop: 6 },
  title: { fontSize: 25, fontWeight: "900", color: "#171717", marginBottom: 12 },
  muted: { color: "#666666", fontSize: 13, marginTop: 4 },
  input: { backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#E5E5E5", borderRadius: 12, paddingHorizontal: 14, paddingVertical: 13, marginTop: 12, color: "#171717" },
  sectionTitle: { color: "#171717", fontWeight: "800", fontSize: 17, marginTop: 22, marginBottom: 10 },
  product: { backgroundColor: "#FFFFFF", borderRadius: 16, padding: 13, marginTop: 10, flexDirection: "row", gap: 12, borderWidth: 1, borderColor: "#EEEEEE" },
  productIcon: { width: 64, height: 76, backgroundColor: "#FFF1E5", borderRadius: 12, alignItems: "center", justifyContent: "center" },
  productName: { color: "#171717", fontWeight: "800", fontSize: 15 },
  price: { color: "#E96B00", fontWeight: "900", fontSize: 16, marginTop: 5 },
  stock: { color: "#23834B", fontSize: 12, marginTop: 3, fontWeight: "700" },
  description: { color: "#666666", fontSize: 12, marginTop: 5, marginBottom: 8 },
  button: { backgroundColor: "#F47700", paddingVertical: 12, paddingHorizontal: 15, borderRadius: 11, alignItems: "center", marginTop: 10 },
  buttonText: { color: "#FFFFFF", fontWeight: "800", fontSize: 13 },
  secondaryButton: { backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#F47700" },
  secondaryButtonText: { color: "#F47700" },
  cartLine: { flexDirection: "row", alignItems: "center", backgroundColor: "#FFFFFF", borderRadius: 12, padding: 12, marginTop: 9 },
  qty: { backgroundColor: "#FFF1E5", width: 30, height: 30, borderRadius: 8, alignItems: "center", justifyContent: "center" },
  qtyText: { marginHorizontal: 12, fontWeight: "800" },
  total: { fontSize: 19, fontWeight: "900", color: "#171717", textAlign: "right", marginTop: 18 },
  choice: { backgroundColor: "#FFFFFF", padding: 13, borderRadius: 10, borderWidth: 1, borderColor: "#E5E5E5", marginTop: 7 },
  choiceActive: { borderColor: "#F47700", backgroundColor: "#FFF1E5" },
  choiceText: { color: "#333333", fontWeight: "600" },
  choiceTextActive: { color: "#D65F00" },
  notice: { backgroundColor: "#FFF3E8", color: "#81420D", padding: 12, borderRadius: 10, marginTop: 15, fontSize: 12, lineHeight: 18 },
  order: { backgroundColor: "#FFFFFF", borderRadius: 13, padding: 14, marginTop: 10, borderWidth: 1, borderColor: "#EEEEEE" },
  status: { color: "#9A4D00", fontWeight: "800", fontSize: 12, marginTop: 8 },
  infoCard: { backgroundColor: "#FFFFFF", borderRadius: 14, padding: 16, marginVertical: 15 },
  listItem: { color: "#444444", backgroundColor: "#FFFFFF", padding: 10, marginTop: 5, borderRadius: 8 },
  nav: { flexDirection: "row", backgroundColor: "#171717", paddingTop: 9, paddingBottom: 10, justifyContent: "space-around" },
  navItem: { alignItems: "center", minWidth: 55 },
  navText: { color: "#AAAAAA", fontSize: 20, fontWeight: "900" },
  navLabel: { color: "#AAAAAA", fontSize: 10, marginTop: 3 },
  navActive: { color: "#FF7A00" }
});
